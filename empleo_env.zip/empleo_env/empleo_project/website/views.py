from django.shortcuts import render

from account.models import Account

# Create your views here.

def home_screen_view(request):
    
    context = {}

    context['some_string'] = "this is a string data passed through context"
    
    accounts = Account.objects.all()
    context['accounts'] = accounts


    return render (request, "sites/home.html",context)